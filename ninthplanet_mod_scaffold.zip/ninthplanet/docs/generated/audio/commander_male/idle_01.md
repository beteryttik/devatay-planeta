# commander_male/idle_01.ogg

Положи сюда запись голоса (реальный человек, мужской).
Формат: OGG Vorbis, до 5 сек.
Путь в ресурсах: assets/ninthplanet/sounds/npc/commander_male/idle_01.ogg