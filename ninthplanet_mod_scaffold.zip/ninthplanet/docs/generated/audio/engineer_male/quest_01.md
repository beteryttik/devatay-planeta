# engineer_male/quest_01.ogg

Положи сюда запись голоса (реальный человек, мужской).
Формат: OGG Vorbis, до 5 сек.
Путь в ресурсах: assets/ninthplanet/sounds/npc/engineer_male/quest_01.ogg